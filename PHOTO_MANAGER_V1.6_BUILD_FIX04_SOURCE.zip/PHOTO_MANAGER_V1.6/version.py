APP_VERSION = "1.6"
APP_AUTHOR = "Chaoching Wu"
