import unittest, tempfile
from pathlib import Path
import numpy as np
from PIL import Image
from clip_local import LABELS, scores_for, decide, preprocess
class TestClip(unittest.TestCase):
    def test_scores(self):
        t=np.eye(sum(map(len,LABELS.values())),dtype=np.float32)
        self.assertEqual(decide(scores_for(t[0],t))[0],'photo')
        self.assertEqual(decide(scores_for(t[3],t)),('screen','greeting'))
        self.assertEqual(decide({'photo':.25,'greeting':.27,'meme':.1,'movie':.1,'screen':.1})[0],'review')
    def test_preprocess(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'test.png'; Image.new('RGB',(400,200),'white').save(p)
            a=preprocess(p); self.assertEqual(a.shape,(1,3,224,224)); self.assertEqual(a.dtype,np.float32); self.assertTrue(np.isfinite(a).all())
if __name__=='__main__': unittest.main()
