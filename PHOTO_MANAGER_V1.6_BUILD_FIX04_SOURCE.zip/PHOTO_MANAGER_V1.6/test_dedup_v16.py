from pathlib import Path
from tempfile import TemporaryDirectory
from photo_manager_v1_4 import Library
from organize import run
import legacy

def put(root,rel,data):
    p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p

def meta(paths,exe):return {}
with TemporaryDirectory() as t:
    root=Path(t);Library(root).close()
    keep=put(root,'PHOTOS/1995/1995-06/1995-06-03_001.JPG',b'original')
    dup=put(root,'00_INBOX/renamed.JPG',b'original')
    cross=put(root,'00_INBOX/screenshot.PNG',b'original')
    edit=put(root,'00_INBOX/edited.JPG',b'edited!!')
    a=put(root,'00_INBOX/a.JPG',b'other');b=put(root,'00_INBOX/b.JPG',b'other')
    live=put(root,'00_INBOX/live.JPG',b'original');video=put(root,'00_INBOX/live.MOV',b'video')
    run(root,'inbox',('duplicates',),metadata=meta)
    assert keep.exists() and not dup.exists() and not cross.exists() and edit.exists()
    assert a.exists() and not b.exists() and live.exists() and video.exists()
    recovery=root/'.PHOTO_MANAGER/recovery'
    assert len(list(recovery.rglob('*.JPG')))==2 and len(list(recovery.rglob('*.PNG')))==1
    run(root,'inbox',('duplicates',),metadata=meta)
    assert len(list(recovery.rglob('*.JPG')))==2
    print('PASS inbox/global/cross-category/exact-only/pair/recovery/idempotence')
with TemporaryDirectory() as t:
    root=Path(t);Library(root).close()
    keep=put(root,'PHOTOS/2024/2024-01/2024-01-01_001.JPG',b'same')
    dup=put(root,'00_INBOX/copy.JPG',b'same')
    run(root,'all',('duplicates','classify','rename'),metadata=meta)
    assert len(list(legacy.scan(root)))==1 and not dup.exists()
    assert len(list((root/'.PHOTO_MANAGER/recovery').rglob('*.JPG')))==1
    print('PASS full scope with rename')
