from tempfile import TemporaryDirectory
from pathlib import Path
from photo_manager_v1_4 import Library,sync,pair_units
from organize import run,execute_moves
from legacy import digest
import os

def put(root,rel,data):
 p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p

def rows(root):
 l=Library(root);r=l.scan(detect=False);l.close();return r
with TemporaryDirectory() as t:
 a,b=[Path(t)/x for x in 'AB']
 for p in (a,b):p.mkdir();Library(p).close()
 for root,n in [(a,1),(b,7)]:
  put(root,f'PHOTOS/2024/2024-01/2024-01-01_{n:03}.JPG',b'p')
  put(root,f'VIDEOS/2024/2024-01/2024-01-01_{n:03}.MOV',b'v')
 sync(a,[(b,'full','')]);assert set(rows(a))==set(rows(b))
 print('PASS canonical pair names across libraries')
with TemporaryDirectory() as t:
 a,b=[Path(t)/x for x in 'AB']
 for p in (a,b):p.mkdir();Library(p).close()
 put(a,'PHOTOS/2024/2024-01/2024-01-01_001.JPG',b'p')
 put(b,'VIDEOS/2024/2024-01/2024-01-01_001.MOV',b'v')
 sync(a,[(b,'backup','')]);assert not pair_units(rows(b))[0]
 sync(a,[(b,'full','')]);assert not pair_units(rows(a))[0] and set(rows(a))==set(rows(b))
 print('PASS independent media do not become false pairs')
with TemporaryDirectory() as t:
 a=Path(t);Library(a).close()
 p=put(a,'00_INBOX/a.JPG',b'p');v=put(a,'00_INBOX/b.MOV',b'v');q=put(a,'00_INBOX/c.JPG',b'q')
 def meta(paths,exe):return {os.path.normcase(str(x)):{'ContentIdentifier':'ABC' if x in (p,v) else '', 'CreateDate':'2024:01:01 12:00:00'} for x in paths}
 run(a,'all',('classify','rename'),metadata=meta);pairs,protected=pair_units(rows(a));assert len(pairs)==1 and len(protected)==2
 print('PASS content identifier across different filenames, independent photo reserved')
for interruption in (2,4):
 with TemporaryDirectory() as t:
  a,b=[Path(t)/x for x in 'AB']
  for p in (a,b):p.mkdir();Library(p).close()
  p=put(a,'00_INBOX/a.JPG',b'p');v=put(a,'00_INBOX/a.MOV',b'v')
  dest=[a/'PHOTOS/2024/2024-01/2024-01-01_001.JPG',a/'VIDEOS/2024/2024-01/2024-01-01_001.MOV'];n=[0]
  def stop():
   n[0]+=1
   if n[0]==interruption:raise InterruptedError('simulated')
  try:execute_moves(a,[(p,dest[0],digest(p)),(v,dest[1],digest(v))],stop=stop)
  except InterruptedError:pass
  assert (a/'.PHOTO_MANAGER/organize_pending.json').exists()
  sync(a,[(b,'full','')]);assert set(rows(a))==set(rows(b)) and len(rows(a))==2
  assert not (a/'.PHOTO_MANAGER/organize_pending.json').exists()
 print('PASS interrupted stage/publish recovery',interruption)
