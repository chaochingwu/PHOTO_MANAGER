PHOTO_MANAGER V1.6a 使用手冊
1. 解壓整個 portable 資料夾，保留 _internal、AI_MODELS、ExifTool 及其附屬資料夾。執行 PHOTO_MANAGER.exe。
2. 選擇或建立照片庫，將待整理檔案放入 00_INBOX。先以副本測試，不要使用唯一原始照片庫。
3. 整理時選擇範圍及分類、命名選項；AI 不刪除照片，疑似圖片保守歸入 PHOTOS。
4. 單向備份：目前庫到目標庫，不傳播刪除。僅匯入：目標庫到目前庫。指定年份：雙向合併該年份，不傳播刪除。完整同步：合併並可能傳播已知刪除，先確認備份。
5. 重複或同步移除檔案位於 .PHOTO_MANAGER/recovery，復原時先複製至獨立資料夾，確認內容後放入 INBOX；勿直接覆蓋現有檔案。
6. 健康檢查與 99_LOG 報告用於核對檔案；Everything 為選用功能。
7. 若中斷，保留 .PHOTO_MANAGER，不要手動刪除暫存或 journal；重新執行整理或同步。
8. Avast 保持啟用，若阻擋請保存警示截圖及隔離資訊。
9. 驗收前勿將 V1.6a 用於唯一正式庫。

PHOTO_MANAGER V1.6a — 正式建置候選版 RC01
基準：DEBUG WIP03；V1.6 原版保留。
本版整合：中文路徑 ExifTool 備援、保守 AI 判斷及報告、完整 Live Photo 配對去重、四種同步模式、日期修復、跨庫命名、中斷續作。
限制：舊庫同名獨立媒體可能被推定為配對；同步端尚未持久化 ContentIdentifier；配對單檔刪除不傳播；sidecar 跨庫差異未完整驗證。不得將此版視為已完成 Windows 驗收。
Windows ExifTool 中文路徑、真實 ONNX 推論、Avast、真實照片庫及復原區復原仍需實測。模型授權 metadata 缺失，對外散布前需確認。
