"""Read-only benchmark; use real positive and negative images in separate folders."""
import argparse,json,time
from pathlib import Path
from clip_local import ClipLocal
p=argparse.ArgumentParser();p.add_argument('--models',default='AI_MODELS');p.add_argument('--screens',required=True);p.add_argument('--photos',required=True);a=p.parse_args()
m=ClipLocal(a.models); results=[]
for expected,folder in [('screen',a.screens),('photo',a.photos)]:
    for f in sorted(Path(folder).iterdir()):
        if not f.is_file():continue
        start=time.perf_counter()
        try:
            verdict,label,scores=m.classify(f); results.append(dict(file=f.name,expected=expected,verdict=verdict,label=label,scores=scores,seconds=time.perf_counter()-start))
        except Exception as e: results.append(dict(file=f.name,expected=expected,error=str(e)))
print(json.dumps(results,ensure_ascii=False,indent=2))
