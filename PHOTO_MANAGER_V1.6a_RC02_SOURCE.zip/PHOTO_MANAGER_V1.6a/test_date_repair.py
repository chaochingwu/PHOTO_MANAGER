from tempfile import TemporaryDirectory
from pathlib import Path
from photo_manager_v1_4 import Library,sync
from organize import run
import os
with TemporaryDirectory() as t:
 a,b=[Path(t)/x for x in 'AB']
 for p in (a,b):p.mkdir();Library(p).close()
 p=a/'VIDEOS/2026/2026-11/2026-11-14_004.MOV';p.parent.mkdir(parents=True);p.write_bytes(b'movie')
 sync(a,[(b,'full','')])
 def meta(paths,exe):return {os.path.normcase(str(x)):{'CreationDate':'2025:07:25 12:00:00'} for x in paths}
 run(a,'all',('classify','rename'),metadata=meta)
 q=a/'VIDEOS/2025/2025-07/2025-07-25_001.MOV';assert q.read_bytes()==b'movie' and not p.exists()
 sync(a,[(b,'full','')]);assert (b/q.relative_to(a)).read_bytes()==b'movie' and not (b/p.relative_to(a)).exists()
 print('PASS existing wrong date repaired and full sync relocates backup without loss')
