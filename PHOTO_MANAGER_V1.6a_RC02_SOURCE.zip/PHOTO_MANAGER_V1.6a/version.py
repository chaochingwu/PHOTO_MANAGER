APP_VERSION = "1.6a"
APP_AUTHOR = "Chaoching Wu"
