from tempfile import TemporaryDirectory
from pathlib import Path
from photo_manager_v1_4 import Library,sync
with TemporaryDirectory() as t:
 a,b,c=[Path(t)/x for x in 'ABC']
 for p in (a,b,c):p.mkdir();Library(p).close()
 def put(p,y,n,data):
  q=p/f'PHOTOS/{y}/{y}-01/{y}-01-01_{n:03}.JPG';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);return q
 x=put(a,1995,1,b'old');z=put(a,2026,1,b'new');r=put(b,2026,2,b'target-only')
 sync(a,[(b,'backup','')]);assert (b/x.relative_to(a)).exists() and not (a/r.relative_to(b)).exists()
 x.unlink();sync(a,[(b,'backup','')]);assert (b/x.relative_to(a)).exists()
 z.write_bytes(b'edited');sync(a,[(b,'backup','')]);assert {p.read_bytes() for p in (b/'PHOTOS').rglob('*.JPG')}=={b'old',b'new',b'edited',b'target-only'}
 x=put(a,1995,1,b'old');q=put(c,1995,2,b'from-c');other=put(c,2026,3,b'other')
 sync(a,[(c,'partial','1995')]);assert (c/x.relative_to(a)).exists() and (a/q.relative_to(c)).exists() and not (c/z.relative_to(a)).exists() and not (a/other.relative_to(c)).exists()
 x.unlink();sync(a,[(c,'partial','1995')]);assert (c/x.relative_to(a)).exists()
 print('PASS backup direction, no deletion, edited versions, partial year both directions, no out-of-year transfer')
with TemporaryDirectory() as t:
 a,b,c=[Path(t)/x for x in 'ABC']
 for p in (a,b,c):p.mkdir();Library(p).close()
 def put(p,y,n,data):
  q=p/f'PHOTOS/{y}/{y}-01/{y}-01-01_{n:03}.JPG';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);return q
 x=put(a,1995,1,b'a');y=put(b,1995,1,b'b');z=put(b,2026,1,b'outside');logs=[]
 sync(a,[(b,'partial','1995')],logs.append)
 assert {p.read_bytes() for p in (a/'PHOTOS').rglob('*.JPG')}=={b'a',b'b'}
 assert {p.read_bytes() for p in (b/'PHOTOS').rglob('*.JPG')}=={b'a',b'b',b'outside'}
 assert any('指定年份 1995' in x for x in logs) and not any('完整庫' in x for x in logs)
 print('PASS partial collision preserves both; explicit mode report')
