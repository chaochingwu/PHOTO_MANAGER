"""Build-time only: download upstream model, export offline ONNX and text vectors."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import torch
from transformers import CLIPModel, CLIPTokenizer
from clip_local import LABELS

def main():
    p=argparse.ArgumentParser(); p.add_argument('--revision',required=True,help='Exact upstream Hugging Face commit SHA'); p.add_argument('--output',default='AI_MODELS'); args=p.parse_args()
    if len(args.revision)!=40 or any(c not in '0123456789abcdef' for c in args.revision): raise ValueError('Use immutable 40-character commit SHA')
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    model_id='openai/clip-vit-base-patch32'
    # This pinned upstream revision provides PyTorch .bin weights, not safetensors.
    # Transformers requires torch >= 2.6 for torch.load; build pins 2.7.1.
    model=CLIPModel.from_pretrained(model_id,revision=args.revision,attn_implementation="eager",use_safetensors=False).eval()
    tokenizer=CLIPTokenizer.from_pretrained(model_id,revision=args.revision)
    class Vision(torch.nn.Module):
        def __init__(self,m): super().__init__(); self.model=m
        def forward(self,pixel_values): return self.model.get_image_features(pixel_values=pixel_values)
    with torch.no_grad():
        tok=tokenizer([s for group in LABELS.values() for s in group],padding=True,return_tensors='pt')
        text=model.get_text_features(input_ids=tok["input_ids"], attention_mask=tok["attention_mask"]).cpu().numpy()
        np.save(out/'text_embeddings.npy',text,allow_pickle=False)
        torch.onnx.export(Vision(model),torch.zeros(1,3,224,224),str(out/'image_encoder.onnx'),input_names=['pixel_values'],output_names=['embedding'],opset_version=17,dynamo=False)
    import onnxruntime as ort
    session=ort.InferenceSession(str(out/'image_encoder.onnx'),providers=['CPUExecutionProvider'])
    rng=np.random.default_rng(42)
    for a in [np.zeros((1,3,224,224),np.float32),rng.standard_normal((1,3,224,224)).astype(np.float32)]:
        with torch.no_grad(): expected=Vision(model)(torch.from_numpy(a)).numpy()
        actual=session.run(None,{'pixel_values':a})[0]
        np.testing.assert_allclose(actual,expected,rtol=2e-3,atol=2e-3)
    print('PASS PyTorch / ONNX embedding parity')
    manifest={'source':model_id,'revision':args.revision,'labels':LABELS,'sha256':{}}
    for name in ('image_encoder.onnx','text_embeddings.npy'):
        with (out/name).open('rb') as f: manifest['sha256'][name]=hashlib.file_digest(f,'sha256').hexdigest()
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
if __name__=='__main__': main()
