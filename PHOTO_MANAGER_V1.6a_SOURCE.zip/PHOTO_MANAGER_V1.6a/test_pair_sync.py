from tempfile import TemporaryDirectory
from pathlib import Path
from photo_manager_v1_4 import Library,sync,pair_units
from legacy import digest
for mode in ('backup','full','partial','import'):
 with TemporaryDirectory() as t:
  a,b=[Path(t)/x for x in 'AB']
  for p in (a,b):p.mkdir();Library(p).close()
  def pair(root,n,photo,video):
   for cat,ext,data in [('PHOTOS','JPG',photo),('VIDEOS','MP4',video)]:
    p=root/f'{cat}/1995/1995-01/1995-01-01_{n:03}.{ext}';p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  src,dst=(b,a) if mode=='import' else (a,b)
  pair(src,1,b'photo',b'video1');pair(src,2,b'photo',b'video2');pair(dst,1,b'other',b'video1')
  sync(a,[(b,mode,'1995' if mode=='partial' else '')]);sync(a,[(b,mode,'1995' if mode=='partial' else '')])
  lib=Library(dst);rows=lib.scan(detect=False);lib.close();pairs,protected=pair_units(rows)
  assert len(pairs)==3 and len(protected)==6,(mode,pairs,protected)
  print('PASS',mode,'shared components, collision, idempotence')
