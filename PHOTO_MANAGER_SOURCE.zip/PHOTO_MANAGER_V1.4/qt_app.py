import os,sys,json,time,threading,queue,datetime,re,sqlite3
from pathlib import Path
from PySide6.QtCore import Qt,QTimer,QUrl
from PySide6.QtGui import QIcon,QFont,QFontDatabase,QDesktopServices
from PySide6.QtWidgets import *
from photo_manager_v1_4 import Library,sync,checkroot,paths_ok,atomic_json,core
BASE=Path(getattr(sys,'_MEIPASS',Path(__file__).parent)); HOME=Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).parent
STYLE='''QWidget{font-size:14px;color:#20354b;background:#f2f5fa} QFrame#card{background:white;border:1px solid #dce4ef;border-radius:12px} QFrame#card QLabel,QFrame#card QWidget{background:transparent} QFrame#nav,QFrame#header{background:#173957} QFrame#nav QLabel,QFrame#header QLabel{color:white;background:transparent} QPushButton{background:white;border:1px solid #cbd7e5;border-radius:8px;padding:10px 16px;font-weight:600} QPushButton:hover{background:#e6f0fc} QPushButton:disabled{color:#8995a5;background:#e9edf2} QPushButton#primary{background:#1769b4;color:white;border:0} QPushButton#primary:hover{background:#217dce} QPushButton#navbutton{background:transparent;color:#e7f1ff;text-align:left;border:0;padding:12px} QPushButton#navbutton:checked{background:#2c76b9;color:white} QLineEdit,QComboBox,QSpinBox{background:white;border:1px solid #cbd7e5;border-radius:7px;padding:8px;min-height:22px} QLineEdit:focus{border:2px solid #2476bf} QProgressBar{background:#e1e8f1;border:0;border-radius:5px;height:10px;text-align:center} QProgressBar::chunk{background:#2581d9;border-radius:5px} QPlainTextEdit{background:white;border:1px solid #dce4ef;border-radius:8px;padding:8px} QScrollArea{border:0} QLabel#heading{font-size:25px;font-weight:700} QLabel#metric{font-size:25px;font-weight:700;color:#173957} QLabel#muted{color:#65788c;font-size:12px}'''
def label(t,name=''):
    w=QLabel(t);w.setObjectName(name);w.setWordWrap(True);return w
def button(t,fn,primary=False):
    b=QPushButton(t);b.clicked.connect(fn);b.setObjectName('primary' if primary else '');return b
def card(title=''):
    w=QFrame();w.setObjectName('card');l=QVBoxLayout(w);l.setContentsMargins(18,16,18,16);l.setSpacing(12)
    if title:l.addWidget(label(title,'heading'))
    return w,l
class Window(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('PHOTO_MANAGER V1.4');self.setWindowIcon(QIcon(str(BASE/'PHOTO_MANAGER.ico')));self.resize(1250,850);self.setMinimumSize(850,650)
        self.cfg=HOME/'CONFIG'/'settings.json';self.cfg.parent.mkdir(exist_ok=True)
        try:c=json.loads(self.cfg.read_text(encoding='utf-8'))
        except Exception:c={}
        self.advanced=c.get('advanced',False);self.busy=False;self.q=queue.Queue();self.stop=threading.Event();self.pause=threading.Event();self.report=None;self.started=0;self.buttons=[]
        self.paths=[QLineEdit(x) for x in c.get('paths',['','',''])];self.modes=[];self.years=[]
        for i in range(2):
            m=QComboBox();m.addItems(['完整同步','僅匯入','指定年份']);m.setCurrentText(c.get('modes',['完整同步','僅匯入'])[i]);self.modes.append(m);y=QLineEdit(c.get('years',['2026','2026'])[i]);y.setMaximumWidth(85);self.years.append(y);m.currentTextChanged.connect(lambda t,y=y:y.setVisible(t=='指定年份'))
        self.inbox=QCheckBox('只整理 INBOX');self.inbox.setChecked(True)
        self.root=QWidget();self.setCentralWidget(self.root);outer=QVBoxLayout(self.root);outer.setContentsMargins(0,0,0,0);outer.setSpacing(0)
        head=QFrame();head.setObjectName('header');hl=QHBoxLayout(head);hl.setContentsMargins(24,18,24,18);ico=QLabel();ico.setPixmap(QIcon(str(BASE/'PHOTO_MANAGER.ico')).pixmap(48,48));hl.addWidget(ico);hl.addWidget(label('PHOTO_MANAGER  /  V1.4 Professional','heading'));hl.addStretch();hl.addWidget(label('免安裝版  •  照片庫管理'));outer.addWidget(head)
        body=QHBoxLayout();body.setContentsMargins(0,0,0,0);body.setSpacing(0);outer.addLayout(body,1)
        self.nav=QFrame();self.nav.setObjectName('nav');self.nav.setFixedWidth(190);nl=QVBoxLayout(self.nav);nl.setContentsMargins(12,16,12,16);body.addWidget(self.nav)
        self.stack=QStackedWidget();body.addWidget(self.stack,1);self.pages={};self.navbuttons={}
        for name in ['總覽','照片整理','影片整理','照片庫同步','重複檔案','照片庫管理','Everything','健康檢查','執行日誌','系統設定']:
            b=button(name,lambda checked=False,n=name:self.showpage(n));b.setObjectName('navbutton');b.setCheckable(True);nl.addWidget(b);self.navbuttons[name]=b
        nl.addStretch();nl.addWidget(button('切換簡易模式',self.toggle));self.simple=self.make_simple();self.stack.addWidget(self.simple)
        for name in self.navbuttons:self.pages[name]=self.make_page(name);self.stack.addWidget(self.pages[name])
        self.footer=QFrame();fl=QHBoxLayout(self.footer);fl.setContentsMargins(18,8,18,8);self.status=label('準備就緒');fl.addWidget(self.status,1);self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setTextVisible(False);fl.addWidget(self.progress,2);self.pausebtn=button('暫停',self.toggle_pause);self.stopbtn=button('安全停止',self.stop.set);fl.addWidget(self.pausebtn);fl.addWidget(self.stopbtn);outer.addWidget(self.footer);self.pausebtn.setEnabled(False);self.stopbtn.setEnabled(False)
        self.timer=QTimer(self);self.timer.timeout.connect(self.poll);self.timer.start(100);self.toggle(initial=True)
    def save(self):atomic_json(self.cfg,{'paths':[x.text() for x in self.paths],'modes':[x.currentText() for x in self.modes],'years':[x.text() for x in self.years],'advanced':self.advanced})
    def browse(self,i):
        p=QFileDialog.getExistingDirectory(self,'選擇照片庫',self.paths[i].text() or str(Path.home()))
        if p:self.paths[i].setText(p);self.save();self.refresh()
    def pathcard(self):
        w,l=card('照片庫設定')
        for i in range(3):
            l.addWidget(label(['目前照片庫','同步照片庫 1','同步照片庫 2'][i]));r=QHBoxLayout();r.addWidget(self.paths[i],1);r.addWidget(button('選擇資料夾',lambda checked=False,i=i:self.browse(i)));l.addLayout(r)
            if i:
                r=QHBoxLayout();r.addWidget(self.modes[i-1],1);r.addWidget(self.years[i-1]);self.years[i-1].setVisible(self.modes[i-1].currentText()=='指定年份');l.addLayout(r)
        l.addWidget(label('僅匯入：選配庫 → 目前庫。指定年份：雙向合併，不傳播刪除。','muted'));return w
    def actions(self,l):
        r=QHBoxLayout()
        for t,a in [('整理照片','organize'),('同步照片庫','sync')]:
            b=button(t,lambda checked=False,a=a:self.start(a),a=='organize');b.setMinimumHeight(82);r.addWidget(b);self.buttons.append(b)
        l.addLayout(r)
    def scroll(self,w):
        s=QScrollArea();s.setWidgetResizable(True);s.setWidget(w);return s
    def make_simple(self):
        w=QWidget();l=QVBoxLayout(w);l.setContentsMargins(30,24,30,24);r=QHBoxLayout();r.addWidget(label('簡易模式','heading'));r.addStretch();r.addWidget(button('進階模式',self.toggle));l.addLayout(r);self.pathbox=self.pathcard();l.addWidget(self.pathbox);self.actions(l);r=QHBoxLayout();r.addWidget(button('開啟 INBOX',self.open_inbox));r.addWidget(button('執行報告',self.open_report));l.addLayout(r);l.addStretch();return self.scroll(w)
    def make_page(self,n):
        w=QWidget();l=QVBoxLayout(w);l.setContentsMargins(26,22,26,22);l.setSpacing(16);l.addWidget(label(n,'heading'))
        if n=='總覽':
            r=QHBoxLayout();self.metrics=[]
            for t in ['照片','影片','已設定照片庫','索引容量']:
                c,cl=card();cl.addWidget(label(t,'muted'));v=label('—','metric');cl.addWidget(v);self.metrics.append(v);r.addWidget(c)
            l.addLayout(r);c,cl=card('快速操作');self.actions(cl);l.addWidget(c);c,cl=card('照片庫狀態');self.states=[label('未設定') for _ in range(3)];[cl.addWidget(x) for x in self.states];cl.addWidget(button('設定照片庫',lambda:self.showpage('照片庫同步')));l.addWidget(c);c,cl=card('執行進度');self.detail=label('尚未執行','muted');cl.addWidget(self.detail);cl.addWidget(button('查看執行日誌',lambda:self.showpage('執行日誌')));l.addWidget(c)
        elif n=='照片庫同步':
            self.pathholder=QVBoxLayout();l.addLayout(self.pathholder);b=button('同步照片庫',lambda:self.start('sync'),True);l.addWidget(b);self.buttons.append(b)
        elif n in ('照片整理','影片整理','重複檔案'):
            c,cl=card('整理與去重');cl.addWidget(label('目前引擎會共同整理照片與影片，以保護 Live Photo。此頁不提供獨立媒體篩選。'));b=button('整理照片與影片',lambda:self.start('organize'),True);cl.addWidget(b);self.buttons.append(b);cl.addWidget(button('開啟 INBOX',self.open_inbox));l.addWidget(c)
        elif n=='照片庫管理':
            c,cl=card('照片庫');cl.addWidget(label('照片庫 UUID 與索引由同步引擎管理。'));cl.addWidget(button('開啟目前照片庫',lambda:self.open_path(self.paths[0].text())));cl.addWidget(button('設定照片庫',lambda:self.showpage('照片庫同步')));l.addWidget(c)
        elif n=='Everything':
            for t,s in [('照片與影片','ext:jpg;jpeg;png;heic;mov;mp4'),('照片','ext:jpg;jpeg;png;heic'),('影片','ext:mov;mp4')]:
                c,cl=card(t);cl.addWidget(label(s));cl.addWidget(button('複製搜尋指令',lambda checked=False,s=s:QApplication.clipboard().setText(s)));l.addWidget(c)
        elif n=='健康檢查':
            c,cl=card('完整雜湊檢查');cl.addWidget(label('讀取所有已歸檔檔案，核對索引；大量照片可能耗時。'));b=button('開始檢查',lambda:self.start('check'),True);cl.addWidget(b);self.buttons.append(b);l.addWidget(c)
        elif n=='執行日誌':
            self.out=QPlainTextEdit();self.out.setReadOnly(True);l.addWidget(self.out,1);l.addWidget(button('開啟 TXT 報告',self.open_report))
        else:
            c,cl=card('系統設定');cl.addWidget(self.inbox);cl.addWidget(label('設定隨程式資料夾保存。字體優先使用 Noto Sans TC，其次使用 Windows 微軟正黑體。'));cl.addWidget(button('儲存設定',self.save));l.addWidget(c)
        l.addStretch();return self.scroll(w)
    def toggle(self,initial=False):
        if self.busy:return
        if not initial:self.advanced=not self.advanced
        self.nav.setVisible(self.advanced)
        if self.advanced:self.showpage('總覽')
        else:
            self.simple.widget().layout().insertWidget(1,self.pathbox);self.stack.setCurrentWidget(self.simple)
        self.save();self.refresh()
    def showpage(self,n):
        if n=='照片庫同步':self.pathholder.addWidget(self.pathbox)
        self.stack.setCurrentWidget(self.pages[n]);[b.setChecked(k==n) for k,b in self.navbuttons.items()];self.refresh()
    def refresh(self):
        p=self.paths[0].text();counts=[0,0,0];db=Path(p)/'.PHOTO_MANAGER/library.db' if p else None
        if db and db.is_file():
            try:
                with sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True) as con:
                    for path,size in con.execute('SELECT path,size FROM files'):counts[0 if path.startswith('PHOTOS/') else 1]+=1;counts[2]+=size
            except Exception:pass
        for v,t in zip(self.metrics,[f'{counts[0]:,}',f'{counts[1]:,}',str(sum(bool(x.text()) for x in self.paths)),f'{counts[2]/1024**3:,.2f} GB']):v.setText(t if p else '—')
        for i,v in enumerate(self.states):
            p=self.paths[i].text();v.setText(f'{["目前庫","同步庫 1","同步庫 2"][i]}  •  '+(p+'  |  '+('可存取' if Path(p).is_dir() else '離線') if p else '未設定'))
    def open_path(self,p):
        if p and Path(p).exists():QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(p).resolve())))
        else:QMessageBox.information(self,'提示','尚未設定或檔案不存在。')
    def open_inbox(self):
        try:
            if not self.paths[0].text().strip():raise ValueError('請選擇目前照片庫')
            p=checkroot(self.paths[0].text())/'00_INBOX';p.mkdir(exist_ok=True);self.open_path(str(p))
        except Exception as e:QMessageBox.warning(self,'錯誤',str(e))
    def open_report(self):self.open_path(str(self.report) if self.report else '')
    def toggle_pause(self):
        if self.pause.is_set():self.pause.clear();self.pausebtn.setText('暫停')
        else:self.pause.set();self.pausebtn.setText('繼續')
    def checkpoint(self):
        while self.pause.is_set() and not self.stop.is_set():time.sleep(.1)
        if self.stop.is_set():raise InterruptedError('使用者停止')
    def start(self,a):
        if self.busy:return
        try:
            if not self.paths[0].text().strip():raise ValueError('請選擇目前照片庫')
            root=checkroot(self.paths[0].text());targets=[]
            for i in range(2):
                p=self.paths[i+1].text();m=['full','import','partial'][self.modes[i].currentIndex()];y=self.years[i].text()
                if p:
                    if m=='partial' and not re.fullmatch(r'\d{4}',y):raise ValueError('年份須為四位數')
                    targets.append((p,m,y))
            if a=='sync' and not targets:raise ValueError('請設定同步庫')
        except Exception as e:QMessageBox.warning(self,'設定錯誤',str(e));return
        if QMessageBox.question(self,'確認操作','此版本仍為候選版，請使用測試複本。整理可能永久刪除重複檔案。是否開始？')!=QMessageBox.StandardButton.Yes:return
        self.save();self.busy=True;self.stop.clear();self.pause.clear();self.started=time.monotonic();self.out.clear();self.progress.setRange(0,0);self.status.setText('執行中');self.pausebtn.setEnabled(a!='organize');self.stopbtn.setEnabled(True);[b.setEnabled(False) for b in self.buttons];inbox=self.inbox.isChecked()
        def worker():
            lines=[];status='完成'
            def log(s):lines.append(str(s));self.q.put(('log',str(s)))
            try:
                if a=='organize':
                    lib=Library(root)
                    try:lib.scan(log,self.checkpoint)
                    finally:lib.close()
                    e=core.Engine(root,log=log,stop=self.stop)
                    try:plan=e.plan(inbox);self.checkpoint();e.execute(plan);self.checkpoint()
                    finally:e.close()
                    lib=Library(root)
                    try:lib.scan(log,self.checkpoint,detect=False)
                    finally:lib.close()
                elif a=='sync':
                    online=[]
                    for p,m,y in targets:
                        if Path(p).is_dir():online.append((p,m,y))
                        else:log('離線，跳過：'+p)
                    if not online:raise IOError('沒有可用同步庫')
                    sync(root,online,log,self.checkpoint)
                else:
                    lib=Library(root)
                    try:
                        rows=lib.scan(log,self.checkpoint,detect=False)
                        for rel,(h,_,__) in rows.items():
                            self.checkpoint()
                            if core.digest(root/rel)!=h:raise IOError('雜湊不符：'+rel)
                        log(f'健康檢查：{len(rows)} 筆')
                    finally:lib.close()
            except Exception as e:status='未完成';log(str(e))
            report=None
            try:
                report=root/'99_LOG'/('PHOTO_MANAGER_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.txt');report.parent.mkdir(exist_ok=True);report.write_text(f'PHOTO_MANAGER V1.4\n結果：{status}\n耗時：{time.monotonic()-self.started:.1f} 秒\n'+'\n'.join(lines),encoding='utf-8-sig')
            except Exception as e:status='報告寫入失敗';log(str(e));report=None
            self.q.put(('done',(status,report)))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        while True:
            try:k,v=self.q.get_nowait()
            except queue.Empty:break
            if k=='log':
                self.out.appendPlainText(v);self.detail.setText(v);m=re.search(r'同步 (\d+)/(\d+)',v)
                if m and int(m[2]):self.progress.setRange(0,int(m[2]));self.progress.setValue(int(m[1]));self.status.setText(f'複製階段 {m[1]}/{m[2]}')
            else:
                self.busy=False;self.status.setText(v[0]);self.report=v[1];self.progress.setRange(0,100);self.progress.setValue(100 if v[0]=='完成' else 0);self.pausebtn.setEnabled(False);self.stopbtn.setEnabled(False);self.pausebtn.setText('暫停');[b.setEnabled(True) for b in self.buttons];self.refresh()
    def closeEvent(self,e):
        if self.busy:QMessageBox.information(self,'執行中','請先安全停止並等待完成。');e.ignore()
        else:self.save();e.accept()
if __name__=='__main__':
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app=QApplication(sys.argv);app.setStyle('Fusion');families=QFontDatabase.families();app.setFont(QFont('Noto Sans TC' if 'Noto Sans TC' in families else 'Microsoft JhengHei',11));app.setStyleSheet(STYLE);w=Window();w.show();sys.exit(app.exec())
