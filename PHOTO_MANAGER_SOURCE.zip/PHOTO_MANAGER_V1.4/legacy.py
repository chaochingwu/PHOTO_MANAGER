import os, re, json, sqlite3, hashlib, shutil, subprocess, datetime as dt, threading, queue, time, csv, uuid
from pathlib import Path
MEDIA=set('.jpg .jpeg .png .heic .heif .tif .tiff .webp .gif .bmp .dng .raw .cr2 .cr3 .nef .arw .orf .raf .rw2 .mov .mp4 .m4v .avi .mts .m2ts .mkv .3gp .wmv .mpg .mpeg'.split())
VIDEO=set('.mov .mp4 .m4v .avi .mts .m2ts .mkv .3gp .wmv .mpg .mpeg'.split())
SEARCH='ext:'+';'.join(sorted(x[1:] for x in MEDIA))
DATE=re.compile(r'(?<!\d)((?:19|20)\d{2})[-_:]?(\d{2})[-_:]?(\d{2})(?!\d)')
FINAL=re.compile(r'^(?:截圖_)?(\d{4}-\d{2}-\d{2})_(\d{3,})$')
SKIP={'99_log','95_duplicates','95_review','98_trash','.photo_manager'}
GENERIC=re.compile(r'^(?:dcim|camera|photos?|pictures?|images?|videos?|google photos|google takeout|takeout|google 相簿|新資料夾.*|\d{3}apple|\d{4}(?:-\d{2})?|pc[-_ ]?\d+|手機備份|相機備份|下載照片|00_inbox)$',re.I)
HELP='''PHOTO_MANAGER V1.3 操作說明

【首次整理】先用少量複本測試。正式壓力測試：A 不動，整理路徑選 B 的照片根目錄，備份路徑選 C 的新空白目錄。不要選整顆系統磁碟。按預覽，再按開始整理；不需逐張確認。
【日常匯入】將其他電腦的照片、影片或整個資料夾複製到主庫 00_INBOX，選 INBOX 模式。保留原始資料夾結構，避免同名覆蓋。Everything 可搜尋下列格式；請避開 Windows、程式及瀏覽器快取、公司機密資料。搜尋結果不要全部平面貼到同一資料夾。
【可複製格式】\n'''+SEARCH+'''
Google Takeout：解壓 ZIP 後保留照片與相鄰 JSON；ZIP 本身不整理。JSON 會保留原件，匹配的副檔會複製至歸檔檔案旁。其他非媒體檔案不移動。
【日期】EXIF > Takeout photoTakenTime（台灣 UTC+8）> 其他 Metadata > 檔名完整日期 > 事件日期 > 最後修改日期。無日期也自動歸檔。截圖依檔名/軟體標記加截圖_，不保證辨識所有截圖。
【事件】保留非通用自訂資料夾名稱（可能包含來源名稱），不猜測新事件。跨月事件按照片日期分月，保留同一事件名稱。已符合年月及命名的照片保留。所有年份都整理。
【重複】SHA-256 完全相同才隔離至 95_DUPLICATES，不永久刪除。相似照片保留；疑似 Live Photo 同目錄同名一圖一片配對，共用編號，整組去重，不拆散。不同內容不覆蓋。
【備份】選填目的地；每組歸檔後複製、驗證。已整理檔案也會補備份。目的地不同內容不覆蓋，不刪除舊檔。重複隔離區也備份。來源及目的地不可互相包含。建議首次目的地空白。
【中斷】按停止，完成當前組後停止；下次重新預覽再執行，已完成檔案不重複改名。99_LOG 保留計畫、SHA-256、來源與目的地、操作紀錄。異常會停止或記錄，不宣稱成功。此版未提供一鍵復原；A 必須保持不動。先用測試複本驗證，再進行全庫壓力測試。
'''
def dateparse(s):
    m=DATE.search(str(s or ''))
    if m:
        try:return dt.date(*map(int,m.groups())).isoformat()
        except ValueError:pass

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def linked(p):return p.is_symlink() or getattr(os.path,'isjunction',lambda x:False)(p)
def scan(root, inbox=False):
    base=root/'00_INBOX' if inbox else root
    for folder,dirs,names in os.walk(base,followlinks=False):
        dirs[:]=sorted(d for d in dirs if d.lower() not in SKIP and not linked(Path(folder)/d))
        for n in sorted(names):
            p=Path(folder)/n
            if p.suffix.lower() in MEDIA and not linked(p):yield p

def sidecar(p):
    for q in (p.with_name(p.name+'.supplemental-metadata.json'),p.with_name(p.name+'.json'),p.with_name(p.name+'.takeout.json'),p.with_suffix('.json')):
        try:
            j=json.loads(q.read_text(encoding='utf-8-sig'))
            if j.get('title') and j['title']!=p.name and not q.name.endswith('.takeout.json'):continue
            if j.get('photoTakenTime'):return q,j
        except (OSError,ValueError,TypeError):pass
    return None,{}
def event(root,p):
    parts=p.relative_to(root).parts[:-1]
    return [x for x in parts if not GENERIC.fullmatch(x) and not re.fullmatch(r'Photos from \d{4}',x,re.I)]
def getdate(p,raw,ev):
    q,j=sidecar(p)
    d=dateparse(raw.get('DateTimeOriginal'))
    if d:return d,'EXIF',q
    try:return dt.datetime.fromtimestamp(int(j['photoTakenTime']['timestamp']),dt.timezone(dt.timedelta(hours=8))).date().isoformat(),'Takeout JSON',q
    except (KeyError,ValueError,TypeError,OverflowError,OSError):pass
    for k in ('CreationDate','CreateDate','MediaCreateDate','TrackCreateDate'):
        d=dateparse(raw.get(k))
        if d:return d,k,q
    d=dateparse(p.stem)
    if d:return d,'檔名',q
    for x in reversed(ev):
        d=dateparse(x)
        if d:return d,'事件日期',q
    return dt.datetime.fromtimestamp(p.stat().st_mtime).date().isoformat(),'FileModifyDate',q

def exif_path():
    return next((str(p) for p in [Path(__import__('sys').executable).parent/'exiftool.exe' if getattr(__import__('sys'),'frozen',False) else Path(__file__).resolve().parent/'exiftool.exe',Path(__file__).resolve().parent/'exiftool'] if p.is_file()),None) or shutil.which('exiftool')
def batchmeta(paths,exe):
    if not exe:raise RuntimeError('找不到 ExifTool，請放在 Python 同目錄')
    out={}
    for i in range(0,len(paths),40):
        chunk=paths[i:i+40]
        cmd=[exe,'-charset','filename=UTF8','-j','-DateTimeOriginal','-CreateDate','-MediaCreateDate','-TrackCreateDate','-Keys:CreationDate','-ContentIdentifier','-Software','-ImageDescription',*[str(p) for p in chunk]]
        r=subprocess.run(cmd,capture_output=True,encoding='utf-8',errors='replace',timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        for row in json.loads(r.stdout):out[os.path.normcase(os.path.abspath(row['SourceFile']))]=row
    return out

def safe_copy(p,d,h):
    d.parent.mkdir(parents=True,exist_ok=True)
    if d.exists():
        if d.is_file() and digest(d)==h:return
        raise FileExistsError(f'不同內容，不覆蓋：{d}')
    tmp=d.with_name(d.name+'.pm-'+uuid.uuid4().hex+'.tmp')
    try:
        shutil.copy2(p,tmp)
        if digest(tmp)!=h:raise IOError('複製驗證失敗')
        # hard link publishes without overwrite, including on NTFS
        os.rename(tmp,d) if os.name=="nt" else os.link(tmp,d)
    finally:
        if tmp.exists():tmp.unlink()

def valid_paths(root,backup):
    root=Path(root).resolve(); backup=Path(backup).resolve() if backup else None
    if not root.is_dir() or root==Path(root.anchor):raise ValueError('請選擇存在的照片資料夾，不可選磁碟根目錄')
    if backup and (backup==Path(backup.anchor) or root==backup or root in backup.parents or backup in root.parents):raise ValueError('備份路徑不可為磁碟根目錄、相同或互相包含')
    return root,backup
# V1.3: preserve V1.3 metadata/date helpers; replace archive/backup engine.
PHOTO={'.jpg','.jpeg','.png','.heic'}
VIDEO={'.mov','.mp4'}
MEDIA=PHOTO|VIDEO
SEARCH='ext:jpg;jpeg;png;heic;mov;mp4'
SKIP |= {'system'}
GENERIC=re.compile(GENERIC.pattern.replace('00_inbox','00_inbox|PHOTOS|VIDEOS|INBOX'),re.I)
HELP="""PHOTO_MANAGER V1.3 測試版
首次：選測試複本及空白備份目錄，預覽後開始。A 原始資料不動。
日常：複製其他電腦的資料至 00_INBOX，選 INBOX 模式；不要平面貼上同名檔案。保留事件資料夾及 Takeout JSON。
Everything：ext:jpg;jpeg;png;heic;mov;mp4
只搜尋照片：ext:jpg;jpeg;png;heic
只搜尋影片：ext:mov;mp4
避開 Windows、Program Files、AppData、程式素材及主庫/備份庫。
PHOTOS / VIDEOS 分庫，YYYY/YYYY-MM/事件/YYYY-MM-DD_001，分庫獨立編號。Live Photo 配對保護，不做相似去重。
完全相同檔案 SHA-256 去重；相似照片採縮圖亮度/色彩及比例比對，保留高像素版本。相似辨識需要 Pillow；HEIC 另需 pillow-heif。未安裝或無法解碼時只做完全相同去重。RAW 等非六種格式不處理。
刪除前驗證保留檔及選定備份；永久刪除，不另留重複區。影片只做 SHA-256。原始 Takeout JSON 保留。
備份只複製正式 PHOTOS/VIDEOS；不清除不明舊備份。已知被替換的低畫質備份僅在雜湊吻合時刪除。請用空白備份測試。
停止後重新預覽續作；99_LOG/V13.db 記錄操作。非原子跨檔案交易，突然斷電後須重新預覽；不提供一鍵復原。正式資料請先保留獨立原始備份。
"""
try:
    from PIL import Image, ImageOps
    try:
        import pillow_heif
        pillow_heif.register_heif_opener()
    except ImportError: pass
except ImportError:
    Image=None

def signature(p):
    if Image is None:return None
    try:
        with Image.open(p) as im:
            im=ImageOps.exif_transpose(im); w,h=im.size
            if min(w,h)<16:return None
            rgb=im.convert('RGB').resize((24,24),Image.Resampling.LANCZOS)
            data=tuple(v for pix in (rgb.get_flattened_data() if hasattr(rgb,"get_flattened_data") else rgb.getdata()) for v in pix)
            # Quality proxy: resolution first; same resolution retains existing version.
            return (w*h,w/h,data)
    except Exception:return None

def similar(a,b):
    if not a or not b or abs(a[1]/b[1]-1)>0.025:return False
    # Conservative threshold, not a guarantee of identity. No flat-color matches.
    x,y=a[2],b[2]
    if max(x)-min(x)<35 or max(y)-min(y)<35:return False
    return sum(abs(i-j) for i,j in zip(x,y))/len(x)<=0.35

def category(p):return 'VIDEOS' if p.suffix.lower() in VIDEO else 'PHOTOS'
class Engine:
    def __init__(self,root,backup=None,log=print,stop=None):
        self.root,self.backup=valid_paths(root,backup);self.log=log;self.stop=stop or threading.Event();self.exe=exif_path()
        for n in ('00_INBOX','99_LOG','PHOTOS','VIDEOS','.PHOTO_MANAGER'):(self.root/n).mkdir(exist_ok=True)
        self.db=sqlite3.connect(self.root/'.PHOTO_MANAGER'/'organize.db');self.db.execute('CREATE TABLE IF NOT EXISTS journal(run TEXT,src TEXT,dst TEXT,sha TEXT,status TEXT,reason TEXT)');self.db.commit()
    def record(self,run,p,d,h,status,why):
        self.db.execute('INSERT INTO journal VALUES(?,?,?,?,?,?)',(run,str(p),str(d),h,status,why));self.db.commit()
    def plan(self,inbox=False):
        paths=list(scan(self.root)); targets=set(scan(self.root,True)) if inbox else set(paths)
        if inbox:paths=[p for p in paths if p in targets or p.is_relative_to(self.root/category(p))]
        groups={}; nums={}; records=[]; result=[]; deletes=[]
        index=self.root/'.PHOTO_MANAGER'/'library.db'
        if index.exists():
            with sqlite3.connect(index) as db:
                nums.update({(cat,day):n for cat,day,n in db.execute("SELECT cat,day,n FROM highwater")})
        for p in paths:
            m=FINAL.fullmatch(p.stem)
            if m and p.is_relative_to(self.root/category(p)):
                k=(category(p),m[1]);nums[k]=max(nums.get(k,0),int(m[2]))
            groups.setdefault((p.parent,p.stem.casefold()),[]).append(p)
        # Also protect already split Live Photo pairs by matching relative path and stem.
        split={}
        for p in paths:
            if p.is_relative_to(self.root/category(p)):
                rel=p.relative_to(self.root/category(p));split.setdefault((rel.parent,rel.stem.casefold()),[]).append(p)
        paired=set()
        for g in list(groups.values())+list(split.values()):
            if len(g)==2 and {category(p) for p in g}=={'PHOTOS','VIDEOS'}:paired.update(g)
        meta={}
        for i in range(0,len(paths),100):
            if self.stop.is_set():raise InterruptedError('預覽停止')
            meta.update(batchmeta(paths[i:i+100],self.exe));self.log(f'讀取日期 {min(i+100,len(paths))}/{len(paths)}')
        for p in paths:
            if self.stop.is_set():raise InterruptedError('預覽停止')
            raw=meta.get(os.path.normcase(str(p)),{});ev=event(self.root,p);d,why,q=getdate(p,raw,ev)
            folder=self.root/category(p)/d[:4]/d[:7]/Path(*ev)
            canonical=p.parent==folder and bool(FINAL.fullmatch(p.stem)) and FINAL.fullmatch(p.stem)[1]==d
            records.append(dict(p=p,h=digest(p),d=d,why=why,q=q,folder=folder,canonical=canonical,sig=signature(p) if category(p)=='PHOTOS' and p not in paired else None,protected=p in paired,raw=raw))
        by_path={r['p']:r for r in records}
        for g in groups.values():
            if len(g)==2 and {category(p) for p in g}=={'PHOTOS','VIDEOS'}:
                photo=next(by_path[p] for p in g if category(p)=='PHOTOS')
                for p in g:
                    r=by_path[p];r['d']=photo['d'];r['folder']=self.root/category(p)/photo['d'][:4]/photo['d'][:7]/Path(*event(self.root,photo['p']))
                    r['canonical']=p.parent==r['folder'] and bool(FINAL.fullmatch(p.stem)) and FINAL.fullmatch(p.stem)[1]==r['d']
        # Prefer existing canonical files, then high resolution, deterministic path.
        records.sort(key=lambda r:(-(r['sig'][0] if r['sig'] else 0),not r['canonical'],str(r['p'])))
        keep=[]; hashes={}; buckets={}
        for r in records:
            if self.stop.is_set():raise InterruptedError('預覽停止')
            p=r['p']; k=(category(p),r['h']); winner=None
            if not r['protected']:
                winner=hashes.get(k)
                if not winner and r['sig']:
                    # Aspect ratio buckets avoid comparing every unrelated orientation.
                    bucket=round(r['sig'][1]*20)
                    for n in range(bucket-2,bucket+3):
                        for candidate in buckets.get(n,[]):
                            if r['sig'][0]!=candidate['sig'][0] and r['d']==candidate['d'] and r['raw'].get('DateTimeOriginal') and r['raw'].get('DateTimeOriginal')==candidate['raw'].get('DateTimeOriginal') and similar(r['sig'],candidate['sig']):winner=candidate;break
                        if winner:break
            if winner and (p in targets or winner['p'] in targets):
                deletes.append((r,winner));continue
            keep.append(r)
            if not r['protected']:
                hashes.setdefault(k,r)
                if r['sig']:buckets.setdefault(round(r['sig'][1]*20),[]).append(r)
        # Pair names share a number where possible; split folders retain relationship by name.
        pairnums={}; used=set(paths)
        for r in sorted(keep,key=lambda r:(not r['canonical'],r['d'],str(r['p']))):
            p=r['p'];d=r['d'];cat=category(p);k=(cat,d)
            if r['canonical'] or p not in targets:r['dest']=p
            else:
                pairkey=(p.parent,p.stem.casefold()) if r['protected'] else None
                n=pairnums.get(pairkey) if pairkey else None
                if n is None or n<=nums.get(k,0):n=max(nums.get(k,0),nums.get(('PHOTOS',d),0) if pairkey else 0,nums.get(('VIDEOS',d),0) if pairkey else 0)+1
                prefix='截圖_' if re.search(r'screenshot|screen[_ -]?shot|截圖|螢幕快照|^snap\d',p.name+' '+str(r['raw'].get('Software','')),re.I) else ''
                dest=r['folder']/f'{prefix}{d}_{n:03d}{p.suffix}'
                while dest in used or dest.exists():n+=1;dest=r['folder']/f'{prefix}{d}_{n:03d}{p.suffix}'
                nums[k]=max(nums.get(k,0),n);used.add(dest);r['dest']=dest
                if pairkey:pairnums[pairkey]=n
            if p in targets:result.append((p,r['dest'],r['h'],r['why'],r['q']))
        self.deletes=[(r['p'],w['dest'],r['h'],w['h'],r['q']) for r,w in deletes]
        self.db.execute('CREATE TABLE IF NOT EXISTS pairs(photo TEXT,video TEXT,PRIMARY KEY(photo,video))')
        for g in groups.values():
            if len(g)==2 and {category(p) for p in g}=={'PHOTOS','VIDEOS'}:
                photo=next(by_path[p]['dest'] for p in g if category(p)=='PHOTOS');video=next(by_path[p]['dest'] for p in g if category(p)=='VIDEOS')
                self.db.execute('INSERT OR IGNORE INTO pairs VALUES(?,?)',(str(photo),str(video)))
        self.db.commit()
        # Persist deletion plan across GUI preview / execution engine instances.
        (self.root/'.PHOTO_MANAGER'/'delete_plan.json').write_text(json.dumps([[str(p),str(d),h,wh,str(q) if q else None] for p,d,h,wh,q in self.deletes],ensure_ascii=False),encoding='utf-8')
        if Image is None:self.log('注意：未安裝 Pillow，本次只做 SHA-256；請先安裝再測相似去重。')
        self.log(f'預覽：保留/整理 {len(result)}，待永久刪除 {len(self.deletes)}；Pillow={Image is not None}')
        return result
    def backup_one(self,p,h):
        if not self.backup:return
        if not any(p.is_relative_to(self.root/n) for n in ('PHOTOS','VIDEOS')):raise ValueError('非正式歸檔，不備份')
        if not self.backup.is_dir():raise IOError('備份資料夾不存在或已離線')
        safe_copy(p,self.backup/p.relative_to(self.root),h)
        q=p.with_name(p.name+'.takeout.json')
        if q.exists():safe_copy(q,self.backup/q.relative_to(self.root),digest(q))
    def execute(self,plan):
        run=uuid.uuid4().hex;done=0;deleted=0
        if self.backup:
            if not self.backup.is_dir():raise IOError('請先建立空白備份資料夾')
            need=sum(p.stat().st_size for p,d,h,w,q in plan if not (self.backup/d.relative_to(self.root)).exists())
            if shutil.disk_usage(self.backup).free<need:raise IOError('備份空間不足')
        for p,d,h,why,q in plan:
            if self.stop.is_set():return self.log('已停止；重新預覽續作')
            if digest(p)!=h:raise IOError('來源已變更，重新預覽')
            self.record(run,p,d,h,'START',why)
            if p!=d:
                d.parent.mkdir(parents=True,exist_ok=True)
                if not d.exists():safe_copy(p,d,h)
                if digest(d)!=h:raise IOError('目的地衝突')
            if q and q.exists():safe_copy(q,d.with_name(d.name+'.takeout.json'),digest(q))
            self.backup_one(d,h)
            if p!=d:p.unlink()
            self.record(run,p,d,h,'OK',why);done+=1
            if done%25==0:self.log(f'歸檔 {done}/{len(plan)}')
        # Backup only canonical archive trees, never inbox/root/duplicate folders.
        if self.backup:
            for n in ('PHOTOS','VIDEOS'):
                for p in scan(self.root/n):
                    if self.stop.is_set():return self.log('已停止；重新預覽續作')
                    self.backup_one(p,digest(p))
        for ps,ds,h,wh,qs in json.loads((self.root/'.PHOTO_MANAGER'/'delete_plan.json').read_text(encoding='utf-8')):
            if self.stop.is_set():return self.log('已停止；重新預覽續作')
            p,d=Path(ps),Path(ds)
            if p==d or not p.is_relative_to(self.root) or not d.is_relative_to(self.root):raise IOError('刪除計畫無效')
            if not p.exists():continue
            if digest(p)!=h or digest(d)!=wh:raise IOError('刪除前驗證失敗')
            self.backup_one(d,wh)
            self.record(run,p,d,h,'DELETE_START','保留版本 '+wh)
            if self.backup and any(p.is_relative_to(self.root/n) for n in ('PHOTOS','VIDEOS')):
                old=self.backup/p.relative_to(self.root)
                if old.exists():
                    if digest(old)!=h:raise IOError('舊備份內容不符，停止刪除')
                    old.unlink()
            p.unlink();self.record(run,p,d,h,'DELETED','保留版本 '+wh);deleted+=1;self.log(f'去重刪除：{p}；保留：{d}；原因：'+('SHA-256 完全相同' if h==wh else '保守相似判定'))
        self.log(f'完成：歸檔 {done}，永久刪除 {deleted}；備份僅 PHOTOS/VIDEOS。')
    def close(self):self.db.close()
