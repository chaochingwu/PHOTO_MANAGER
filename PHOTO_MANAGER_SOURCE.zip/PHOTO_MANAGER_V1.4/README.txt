PHOTO_MANAGER V1.4 Qt 介面重構候選包
Windows：解壓至新資料夾，執行 BUILD_EXE.bat 一次，完成後執行 dist\PHOTO_MANAGER\PHOTO_MANAGER.exe。不要覆蓋舊版的 _internal。
建置使用既有 Thonny Portable Python 3.14.4，需網路下載 PySide6 等套件。成品可攜，不需 Python。尚未在 Windows 建置或執行驗證。
Qt 6 原生高 DPI；優先使用已安裝 Noto Sans TC，否則微軟正黑體。未附字型檔。
本版重構 UI，保留既有同步引擎。只用測試複本；仍未完成跨庫命名一致、部分同步的資料夾與媒體篩選、完整斷電復原、Live Photo 跨庫交易保護。整理會永久刪除重複檔案。
