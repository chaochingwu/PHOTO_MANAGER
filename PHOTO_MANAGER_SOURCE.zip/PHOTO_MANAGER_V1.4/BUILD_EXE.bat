@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=D:\Program Files For Green\thonny-5.0.0-windows-portable-x64\python.exe"
set "LOG=%~dp0BUILD_LOG.txt"
>"%LOG%" echo PHOTO_MANAGER V1.4 build
if not exist "%PY%" goto fail
if not exist "photo_manager_v1_4.py" goto fail
if not exist "requirements.txt" goto fail
if not exist "exiftool.exe" goto fail
if not exist "exiftool_files\" goto fail
 echo Checking Python...
"%PY%" -c "import sys; print(sys.version)" >>"%LOG%" 2>&1
if errorlevel 1 goto fail
set "BP=%PY%"
 echo Installing dependencies. Please wait...
"%BP%" -m pip install --upgrade pip >>"%LOG%" 2>&1
if errorlevel 1 goto fail
"%BP%" -m pip install -r requirements.txt >>"%LOG%" 2>&1
if errorlevel 1 goto fail
"%BP%" -c "import PySide6, PIL, pillow_heif, PyInstaller; print(PyInstaller.__version__)" >>"%LOG%" 2>&1
if errorlevel 1 goto fail
 echo Building Windows EXE. Please wait...
"%BP%" -m PyInstaller --noconfirm --clean --onedir --windowed --name PHOTO_MANAGER --icon PHOTO_MANAGER.ico --add-data "PHOTO_MANAGER.ico;." --collect-all pillow_heif qt_app.py >>"%LOG%" 2>&1
if errorlevel 1 goto fail
set "OUT=%~dp0dist\PHOTO_MANAGER"
copy /y "exiftool.exe" "%OUT%\" >>"%LOG%" 2>&1
if errorlevel 1 goto fail
xcopy /e /i /y "exiftool_files" "%OUT%\exiftool_files" >>"%LOG%" 2>&1
if errorlevel 1 goto fail
for %%F in (README.txt DEVELOPMENT_LOG.txt CHANGELOG.txt SPECIFICATION.txt TEST_RESULTS.txt) do if exist "%%F" copy /y "%%F" "%OUT%\" >>"%LOG%" 2>&1
if not exist "%OUT%\SOURCE\" mkdir "%OUT%\SOURCE"
for %%F in (qt_app.py photo_manager_v1_4.py legacy.py requirements.txt BUILD_EXE.bat test_sync.py PHOTO_MANAGER.ico PHOTO_MANAGER.png) do if exist "%%F" copy /y "%%F" "%OUT%\SOURCE\" >>"%LOG%" 2>&1
if not exist "%OUT%\PHOTO_MANAGER.exe" goto fail
 echo SUCCESS: "%OUT%\PHOTO_MANAGER.exe"
>>"%LOG%" echo SUCCESS
explorer "%OUT%"
pause
exit /b 0
:fail
 echo BUILD FAILED. See "%LOG%"
>>"%LOG%" echo BUILD FAILED
 type "%LOG%"
pause
exit /b 1
