@echo off
cd /d "%~dp0"
if exist "dist\PHOTO_MANAGER\PHOTO_MANAGER.exe" (start "" "dist\PHOTO_MANAGER\PHOTO_MANAGER.exe") else (call BUILD_EXE.bat)
