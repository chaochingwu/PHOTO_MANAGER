from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from types import SimpleNamespace
from PIL import Image
import legacy as core
from library_setup import initialize
from organize import run
with TemporaryDirectory() as t:
    root=initialize(Path(t),'家庭照片庫'); p=root/'00_INBOX'/'001.jpg'
    ex=Image.Exif();ex[36867]='2021:03:04 12:34:56';ex[271]='Test camera';Image.new('RGB',(320,240),'blue').save(p,exif=ex)
    logs=[]
    with patch('legacy.subprocess.run',return_value=SimpleNamespace(stdout=b'',stderr=b'bad filename',returncode=1)):
        run(root,'inbox',('classify','rename'),log=logs.append)
    dest=root/'PHOTOS/2021/2021-03/2021-03-04_001.JPG';assert dest.exists() and not p.exists();assert any('ExifTool 批次失敗' in x for x in logs)
    # Actual bundled ExifTool on Windows, not mocked. Unicode path and genuine JPEG.
    import os
    if os.name=='nt':
        result=core.batchmeta([dest],core.exif_path(),print);row=result[os.path.normcase(str(dest.absolute()))];assert row.get('DateTimeOriginal')=='2021:03:04 12:34:56';assert row.get('SourceFile'), 'Bundled ExifTool did not return actual JSON'
    run(root,'inbox',('screenshots',),log=logs.append);assert any('零筆亦為正常完成' in x for x in logs)
print('PASS empty ExifTool output, real JPEG EXIF fallback, Unicode library, zero files')
