from tempfile import TemporaryDirectory
from pathlib import Path
from library_setup import initialize,info,open_library
from photo_manager_v1_4 import sync
with TemporaryDirectory() as t:
    p=Path(t).resolve(); a=p/'個人資料'/'影像';a.mkdir(parents=True);b=p/'備份';b.mkdir();c=p/'其他';c.mkdir()
    x=initialize(a,'家庭照片庫');y=initialize(b,'家庭照片庫',source=x)
    assert x.name==y.name and info(x)['group']==info(y)['group'] and info(x)['uuid']!=info(y)['uuid']
    assert all((x/n).is_dir() for n in ('PHOTOS','VIDEOS','00_INBOX','99_LOG'))
    z=initialize(c,'家庭照片庫');assert info(z)['group']!=info(x)['group']
    try:sync(x,[(z,'full','')]);raise AssertionError('unrelated group accepted')
    except IOError:pass
    old=p/'舊照片';old.mkdir();(old/'original.jpg').write_bytes(b'original');assert initialize(old,'舊照片',True)==old.resolve();assert (old/'original.jpg').read_bytes()==b'original'
    moved=p/'搬移';x.rename(moved);assert info(open_library(moved))['group']==info(y)['group']
    try:initialize(moved,'nested');raise AssertionError('nested accepted')
    except ValueError:pass
    q=moved/'PHOTOS/2026/2026-11/2026-11-13_001.JPG';q.parent.mkdir(parents=True);q.write_bytes(b'photo');sync(moved,[(y,'full','')]);assert (y/q.relative_to(moved)).read_bytes()==b'photo'
    print('PASS named libraries, nested paths, backup group, unrelated rejection, existing folder, move, sync')
