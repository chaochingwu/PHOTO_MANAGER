@echo off
cd /d "%~dp0"
"%~dp0exiftool.exe" -ver
pause
