from tempfile import TemporaryDirectory
from pathlib import Path
from photo_manager_v1_4 import Library,sync
with TemporaryDirectory() as t:
    a,b,c=[Path(t)/x for x in 'ABC']
    for p in (a,b,c):p.mkdir();Library(p).close()
    def put(p,n,content):
        q=p/'PHOTOS/2026/2026-11'/f'2026-11-13_{n:03d}.JPG';q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(content);return q
    q=put(a,1,b'a');sync(a,[(b,'full',''),(c,'full','')]);assert (b/q.relative_to(a)).read_bytes()==b'a'
    q.unlink();sync(a,[(b,'full',''),(c,'full','')]);assert not (b/q.relative_to(a)).exists()
    r=put(c,2,b'b');sync(a,[(b,'full',''),(c,'import','')]);assert (a/r.relative_to(c)).exists();assert (b/r.relative_to(c)).exists()
    put(a,3,b'c');sync(a,[(c,'import','')]);assert not (c/'PHOTOS/2026/2026-11/2026-11-13_003.JPG').exists()
    print('PASS basic copy, deletion, import, no reverse copy')
