from everything_search import PHOTO_EXT,VIDEO_EXT,search_command
import legacy
assert len(PHOTO_EXT)==len(VIDEO_EXT)==12
assert legacy.MEDIA=={'.'+x for x in PHOTO_EXT+VIDEO_EXT}
assert search_command(['jpg'],['mov'])=='ext:jpg;mov'
assert search_command([],[])==''
assert search_command(['jpg'],[],r'D:\家庭 照片')=='"D:\\家庭 照片\\" ext:jpg'
assert search_command(['jpg','raw'],[])=='ext:jpg'
from pathlib import Path
for x in PHOTO_EXT:assert legacy.category(Path('x.'+x.upper()))=='PHOTOS'
for x in VIDEO_EXT:assert legacy.category(Path('x.'+x.upper()))=='VIDEOS'
print('PASS 24 formats, category, search command, folder, empty selection')
