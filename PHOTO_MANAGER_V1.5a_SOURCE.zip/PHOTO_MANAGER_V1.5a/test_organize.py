from tempfile import TemporaryDirectory
from pathlib import Path
from photo_manager_v1_4 import Library,sync
from organize import run
import os
with TemporaryDirectory() as t:
    a,b=[Path(t)/x for x in 'AB']
    for p in (a,b):p.mkdir();Library(p).close()
    folder=a/'PHOTOS/2024/2024-01';folder.mkdir(parents=True)
    p=folder/'2024-01-01_001.JPG';q=folder/'2024-01-01_002.JPG';r=folder/'截圖_2024-01-01_003.PNG'
    for f,v in [(p,b'late'),(q,b'early'),(r,b'screen')]:f.write_bytes(v)
    sync(a,[(b,'full','')]);
    def meta(paths,exe):return {os.path.normcase(str(x)):{'DateTimeOriginal':'2024:01:01 '+('09:00:00' if x.read_bytes()==b'early' else '12:00:00')} for x in paths}
    run(a,'all',('screenshots',),metadata=meta)
    assert p.read_bytes()==b'late' and q.read_bytes()==b'early';assert (a/'截圖/截圖_2024-01-01_001.PNG').read_bytes()==b'screen'
    run(a,'all',('classify','rename'),metadata=meta)
    assert p.read_bytes()==b'early' and q.read_bytes()==b'late'
    sync(a,[(b,'full','')]);assert (b/p.relative_to(a)).read_bytes()==b'early';assert (b/'截圖/截圖_2024-01-01_001.PNG').exists()
    assert not (b/r.relative_to(a)).exists()
    print('PASS screenshot-only, chronological swap, sync relocation')
